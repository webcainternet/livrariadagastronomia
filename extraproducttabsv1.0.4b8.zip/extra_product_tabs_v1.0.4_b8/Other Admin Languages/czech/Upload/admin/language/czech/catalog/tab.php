<?php
/*  Czech translation provided by Honza Anděl (http://www.facebook.com/hnzl1) many thanks
	
	---------------------------------------------------------------------
			Name:		Extra Product Tabs Opencart Extension
			
			Version: 1.0.4

			OpenCart:	Version 1.5.4.1

			Author: 	rebdog (Godfrey Livinsgtone godfrey@satelliteshop.co.nz)

			Copyright 2012, 2013

*/
		
// Heading
$_['heading_title']     = 'Extra záložky produktu';

// Text
$_['text_success']      = 'Úspěch: Upravili jste záložku produktu!';
$_['text_position_1']   = 'Před všechny systémové záložky';
$_['text_position_2']   = 'Mezi popisové a atributové záložky';
$_['text_position_3']   = 'Mezi atributové a revidované záložky';
$_['text_position_4']   = 'Mezi revidované a související záložky';
$_['text_position_5']   = 'Za všechny systémové záložky';

// Column
$_['column_name']       = 'Název záložky produktu';
$_['column_sort_order'] = 'Řazení';
$_['column_action']     = 'Akce';

// Entry
$_['entry_name']        = 'Název záložky produktu';
$_['entry_sort_order']  = 'Řazení';
$_['entry_status']      = 'Stav záložky:<span class="help">Pokud je zakázán, tato záložka nebude zobrazena na stránce katalog produktů.</span>';
$_['entry_position']    = 'Pozice:<span class="help">Relativní pozice k system/default tabs.</span>';
$_['entry_show_empty']  = 'Zobrazit prázdné:<span class="help">Vyberte \'Yes\' pokud chcete zobrazovat prázdné záložky na stránce katalogu produktů.</span>';

// Existing tab names
$_['tab_description']   = 'Popis';
$_['tab_attribute']     = 'Atributy';
$_['tab_review']        = 'Přehled';
$_['tab_related']       = 'Související';

// Error
$_['error_permission']  = 'Pozor: Nemáte oprávnění k úpravě Extra záložky produktů!';
$_['error_name']        = 'Jméno Extra záložky produktů musí být 3 až 64 znaků dlouhé!';
$_['error_product_tab'] = 'Pozor: Tato Extra záložka produktů nemůže být odstraněna, jelikož je právě používána %s produkty!';

?>