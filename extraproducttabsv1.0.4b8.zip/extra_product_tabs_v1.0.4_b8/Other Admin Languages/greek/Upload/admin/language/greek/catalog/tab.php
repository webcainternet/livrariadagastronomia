<?php
/*  Greek translation provided by Ilias Christodoulou (xristodoyloy@hotmail.com) many thanks
	
	---------------------------------------------------------------------
			Name:		Extra Product Tabs Opencart Extension
			
			Version: 1.0.4

			OpenCart:	Version 1.5.4.1

			Author: 	rebdog (Godfrey Livinsgtone godfrey@satelliteshop.co.nz)

			Copyright 2012, 2013

*/
		
// Heading
$_['heading_title']     = 'Επιπλέον Καρτέλες Προϊόντων';

// Text
$_['text_success']      = 'Έχετε επεξεργαστεί επιτυχώς τις καρτέλες των προϊόντων!';
$_['text_position_1']   = 'Πριν τις καρτέλες του συστήματος';
$_['text_position_2']   = 'Ανάμεσα στην περιγραφή και τα χαρακτηριστικά';
$_['text_position_3']   = 'Ανάμεσα στα χαρακτηριστικά και στις αξιολογήσεις';
$_['text_position_4']   = 'Ανάμεσα στις αξιολογήσεις και τα σχετικά προϊόντα';
$_['text_position_5']   = 'Μετά τις καρτέλες του συστήματος';

// Column
$_['column_name']       = 'Όνομα καρτέλας Προϊόντος';
$_['column_sort_order'] = 'Σειρά Ταξινόμησης';
$_['column_action']     = 'Ενέργεια';

// Entry
$_['entry_name']        = 'Όνομα καρτέλας Προϊόντος:';
$_['entry_sort_order']  = 'Σειρά Ταξινόμησης:';
$_['entry_status']      = 'Κατάσταση Καρτέλας:<span class="help">Αν απενεργοποιηθεί αυτή η καρτέλα δεν θα εμφανίζεται στην σελίδα του προϊόντος.</span>';
$_['entry_position']    = 'Θέση:<span class="help">Θέση σε σχέση με τις καρτέλες του συστήματος.</span>';
$_['entry_show_empty']  = 'Εμφάνιση Κενών:<span class="help">Επιλέξτε ναι αν θέλετε μία κενή καρτέλα να εμφανίζεται στην σελίδα του προϊόντος.</span>';

// Existing tab names
$_['tab_description']   = 'Περιγραφή';
$_['tab_attribute']     = 'Χαρακτηριστικά';
$_['tab_review']        = 'Αξιολoγήσεις';
$_['tab_related']       = 'Σχετικά Προϊόντα';

// Error
$_['error_permission']  = 'Προειδοποίηση: Δεν έχετε τα δικαιώματα για να επεξεργαστείτε τις Επιπλέον Καρτέλες Προϊόντων!';
$_['error_name']        = 'Το όνομα της καρτέλας προϊόντος πρέπει να είναι από 3 μέχρι 64 χαρακτήρες!';
$_['error_product_tab'] = 'Προειδοποίηση: Αυτή η Καρτέλα Προϊόντος δεν μπορεί να διαγραφεί επειδή χρησιμοποιείται από %s προϊόντα!';

?>