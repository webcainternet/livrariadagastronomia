<?php
/*

	Chinese (Taiwanese Mandarin) thanks to forum member fei
	
	This file is part of the "Extra Product Tabs Opencart Extension"

	The "Extra Product Tabs Opencart Extension" is free software: you can redistribute it and/or modify it under
	the terms of the GNU General Public License as published by the Free Software
	Foundation, either version 3 of the License, or (at your option) any later version.

	The Extra Product Tabs Opencart Extension is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
	FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

	---------------------------------------------------------------------
  Name:		Extra Product Tabs Opencart Extension
  
  Version: 1.0.4

  OpenCart:	Version 1.5.4.1, 1.5.4.1

  Author: 	rebdog (Godfrey Livinsgtone godfrey@satelliteshop.co.nz)

  Copyright 2012, 2013

*/

// Heading
$_['heading_title']     = '額外商品索引標籤';

// Text
$_['text_success']      = '已成功修商品索引標籤模組!';
$_['text_position_1']   = '所有系統索引標籤前';
$_['text_position_2']   = '描述和屬性索引標籤之間';
$_['text_position_3']   = '屬性和評論索引標籤之間';
$_['text_position_4']   = '評論和相關商品索引標籤之間';
$_['text_position_5']   = '所有系統索引標籤後';

// Column
$_['column_name']       = '商品索引標籤名稱';
$_['column_sort_order'] = '排序';
$_['column_action']     = '動作';

// Entry
$_['entry_name']        = '商品索引標籤名稱:';
$_['entry_sort_order']  = '排序:';
$_['entry_status']  		= '索引標籤狀態:<span class="help">如果停用，此索引標籤將不會在目錄商品頁面顯示。</span>';
$_['entry_position']  	= '位置:<span class="help">相對系統/預設索引標籤的位置。</span>';
$_['entry_show_empty']  = '顯示空的:<span class="help">選取「是」，如果您要在目錄商品頁面顯示空的索引標籤。</span>';

// Existing tab names
$_['tab_description']   = '排序';
$_['tab_attribute']     = '屬性';
$_['tab_review']  			= '評論';
$_['tab_related']  			= '相關商品';

// Error
$_['error_permission']  = '警告: 您沒有權限修改額外商品索引標籤模組!';
$_['error_name']        = '額外商品索引標籤名稱必須在 3 到 64 個字串之間!';
$_['error_product_tab'] = '警告: 此商品索引標籤無法刪除，因為目前有 %s 個商品使用!';
?>