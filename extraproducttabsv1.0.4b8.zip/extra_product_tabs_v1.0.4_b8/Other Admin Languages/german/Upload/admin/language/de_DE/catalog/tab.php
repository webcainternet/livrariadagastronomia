<?php
/*
	
	German translation provided by Christian Prim (christian.prim@gmx.ch) many thanks
	
	This file is part of the "Extra Product Tabs Opencart Extension"

	The "Extra Product Tabs Opencart Extension" is free software: you can redistribute it and/or modify it under
	the terms of the GNU General Public License as published by the Free Software
	Foundation, either version 3 of the License, or (at your option) any later version.

	The Extra Product Tabs Opencart Extension is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
	FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

	---------------------------------------------------------------------
		Name:		Extra Product Tabs Opencart Extension
		
		Version: 1.0.4

		OpenCart:	Version 1.5.4.1

		Author: 	rebdog (Godfrey Livinsgtone godfrey@satelliteshop.co.nz)

		Copyright 2012, 2013

*/

// Heading
$_['heading_title']     = 'Zusätzliche Produktreiter';

// Text
$_['text_success']      = 'Erfolgreich: Sie haben den Produktreiter verändert!';
$_['text_position_1']   = 'Vor allen Systemreitern';
$_['text_position_2']   = 'Zwischen der Beschreibung und den Optionen';
$_['text_position_3']   = 'Zwischen Optionen und Beurteilungen';
$_['text_position_4']   = 'Zwischen Beurteilungen und Ähnliche Produkte';
$_['text_position_5']   = 'Nach allen Systemreitern';

// Column
$_['column_name']       = 'Name des Reiters';
$_['column_sort_order'] = 'Reihenfolge';
$_['column_action']     = 'Aktion';

// Entry
$_['entry_name']        = 'Name des Reiters:';
$_['entry_sort_order']  = 'Reihenfolge:';
$_['entry_status']  		= 'Status:<span class="help">Falls inaktiv, erscheint der Reiter nicht.</span>';
$_['entry_position']  	= 'Position:<span class="help">Position relative zu den Systemreitern.</span>';
$_['entry_show_empty']  = 'Leer anzeigen:<span class="help">\'Ja\', falls auch ein leerer Reiter angezeigt werden soll.</span>';

// Existing tab names
$_['tab_description']   = 'Beschreibung';
$_['tab_attribute']     = 'Eigenschaft';
$_['tab_review']  			= 'Beurteilung';
$_['tab_related']  			= 'Ähnliche Produkte';
$_['tab_product_tab']	= 'Zusätzliche Reiter';

// Error
$_['error_permission']  = 'Warnung: Sie haben keine Rechte, diese Reiter zu verändern!';
$_['error_name']        = 'Der Name des Reiters muss zwischen 3 und 32 Buchstaben haben!';
$_['error_product_tab'] = 'Warnung: Dieser Reiter kann nicht gelöscht werden, da er von %s Produkten benutzt wird!';
?>