<?php
/*  Swedish translation provided by Andreas Tjärnberg (andreas@skadeprevention.se) many thanks
	
	---------------------------------------------------------------------
			Name:		Extra Product Tabs Opencart Extension
			
			Version: 1.0.4

			OpenCart:	Version 1.5.4.1

			Author: 	rebdog (Godfrey Livinsgtone godfrey@satelliteshop.co.nz)

			Copyright 2012, 2013

*/
		
// Heading
$_['heading_title']     = 'Extra produktflikar';

// Text
$_['text_success']      = 'Du har ändrat i extraflikarna!';
$_['text_position_1']   = 'Före alla systemflikar';
$_['text_position_2']   = 'Mellan beskrivning och specifikationer';
$_['text_position_3']   = 'Mellan specifikationer och recensioner';
$_['text_position_4']   = 'Mellan recensioner och relaterade produkter';
$_['text_position_5']   = 'Efter alla systemflikar';

// Column
$_['column_name']       = 'Namn på fliken';
$_['column_sort_order'] = 'Sorteringsordning';
$_['column_action']     = 'Verkställ';

// Entry
$_['entry_name']        = 'Fliknamn:';
$_['entry_sort_order']  = 'Sorteringsordning:';
$_['entry_status']      = 'Flikstatus:<span class="help">Om du väljer disabled så syns inte fliken på produktsidan.</span>';
$_['entry_position']    = 'Position:<span class="help">Positionen är relativ till systemflikar och ordinarie flikar.</span>';
$_['entry_show_empty']  = 'Visa tom:<span class="help">Select \'Yes\' om du vill visa en tom flik på produktsidan.</span>';

// Existing tab names
$_['tab_description']   = 'Beskrivning';
$_['tab_attribute']     = 'Specifikationer';
$_['tab_review']        = 'Recensioner';
$_['tab_related']       = 'Relaterade produkter';

// Error
$_['error_permission']  = 'Varning: Du har inte tillstånd att ändra extraflikarna.';
$_['error_name']        = 'Namnet måste vara mellan 3 och 64 tecken!';
$_['error_product_tab'] = 'Varning: Den här extrafliken kan inte tas bort eftersom den används av %s produkter!';

?>