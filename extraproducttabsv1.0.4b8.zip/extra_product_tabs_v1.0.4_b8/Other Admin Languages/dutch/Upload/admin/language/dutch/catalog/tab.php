<?php
/*  Dutch translation provided by Geert J. (vjsmoke@hotmail.com) many thanks
	
	---------------------------------------------------------------------
			Name:		Extra Product Tabs Opencart Extension
			
			Version: 1.0.4

			OpenCart:	Version 1.5.4.1, 1.5.5.1

			Author: 	rebdog (Godfrey Livinsgtone godfrey@satelliteshop.co.nz)

			Copyright 2012, 2013

*/
		
// Heading
$_['heading_title']     = 'Extra Product Tabs';

// Text
$_['text_success']      = 'Success: Je hebt Product Tabs gewijzigd!';
$_['text_position_1']   = 'Voor Alle System Tabs';
$_['text_position_2']   = 'Tussen beschrijving en Attributen Tabs';
$_['text_position_3']   = 'Tussen Attributen en review Tabs';
$_['text_position_4']   = 'Tussen Review and gerelateerde Tabs';
$_['text_position_5']   = 'Na alle System Tabs';

// Column
$_['column_name']       = 'Product Tab Naam';
$_['column_sort_order'] = 'Sorteervolgorde';
$_['column_action']     = 'AKtie';

// Entry
$_['entry_name']        = 'Product Tab Name:';
$_['entry_sort_order']  = 'Sorteervolgorde:';
$_['entry_status']      = 'Tab Status:<span class="help">Als dit is uitgeschakeld dan is deze tab niet zichtbaar op de catalogus producten pagina.</span>';
$_['entry_position']    = 'Positie:<span class="help">Positie relative to system/default tabs.</span>';
$_['entry_show_empty']  = 'Show Empty:<span class="help">Selecteer \'Ja\' Als je een lege tab wil zien in de catalogus producten pagina.</span>';

// Existing tab names
$_['tab_description']   = 'Omschrijving';
$_['tab_attribute']     = 'Specificatie';
$_['tab_review']        = 'Beoordelingen';
$_['tab_related']       = 'Bekijk ook...';

// Error
$_['error_permission']  = 'Waarschuwing: Je hebt geen toestemming om Extra Product Tabs aan te passen!';
$_['error_name']        = 'De Extra Product Tab Naam moet tussen 3 and 64 tekens lang zijn!';
$_['error_product_tab'] = 'Waarschuwing: Deze Extra Product Tab kan niet verwijdert worden omdat het wordt gebruikt door %s producten!';

?>