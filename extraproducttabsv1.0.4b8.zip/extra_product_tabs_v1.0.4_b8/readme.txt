Name:		Extra Product Tabs Opencart Extension

Version: 1.0.4

OpenCart:	Version 1.5.4.1, 1.5.5.1

Author: 	rebdog (Godfrey Livinsgtone godfrey@satelliteshop.co.nz)

Copyright 2012, 2013

How to install it:
==================
Please see install.txt

What it does 
===================
* You can create as many extra tabs as you need, in any position relative to the system tabs
* Edit tab content with WYSIWYG editor.
* Multi language support for the extra tabs created (The admin interface is is English only, sorry, if anyone wants to contribute a translation will add it)
* You can add one or more of the tabs you have created on a product.  Each Product only has the tabs you have added to it.
* The product tabs all have seperate content. 

Sorry there is no demo, this extension is free so you can test it yourself

Admin Languages
===================
The admin interface is available in English, Geeek, Czech and 


OpenCart Version
===================
* Tested only on versions 1.5.4.1 and 1.4.5.1 with the default theme only and requires that the english language is install for admin
* Greek is also supported as an Admin Language

Support
=======
I created this extension, to solve a need I had, and it is offered free.  I will try to answer questions if possible, when time permits.

I will not be backporting this to any other version, sorry!  Nor will I be adding any further features, if you need more features or support, there are paid extensions out there, that you can purchase if needed.

Removing
========
The extension uploads the following files

admin/controller/catalog/tab.php
admin/language/english/catalog/tab.php
admin/controller/catalog/tab.php
admin/model/catalog/tab.php
admin/view/template/catalog/tab_form.tpl
admin/view/template/catalog/tab_list.tpl

vqmod/xml/extra_product_tab_admin.xml  (Changes to the Admin files) 
vqmod/xml/extra_product_tab_catalog.xml (Changes to the Catalog files) 

vqmod/xml/extra_product_tab.xml (This is from an earlier version and should be removed)

If you have added other 'Administration Languages' then will also add
admin/language/'admin language'/catalog/tab.php eg admin/language/greek/catalog/tab.php


And creates the following tables
tab, tab_description and product_tab

You can remove the tables from your database as follows

drop table tab;
drop table tab_description;
drop table product_tab;

or if you hagve used a DB_PREFIX
drop table DB_PREFIX.tab;
drop table DB_PREFIX.tab_description;
drop table DB_PREFIX.product_tab;

replacing DB_PREFIX with the prefix you used.

Copyright
========
Godfrey Livinsgtone 2012, 2013 godfrey@satelliteshop.co.nz

Licience
========

This extension is provided for free, I hope it proves useful.

This extension is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This extension is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this extension.  If not, see <http://www.gnu.org/licenses/>.
