CKEditor 4.4.4 Full (English)
For OpenCart v1.5.4 / 1.5.5 / 1.5.6 / 1.6.0
License: freeware(opensource)

Author: villagedefrance
email: contact@villagedefrance.net
web: www.villagedefrance.net

DESCRIPTION:

CKEditor 4.4.4 Full Version for Opencart, with "moonocolor" skin, is a major upgrade for your shop administration. It replaces the default CKEditor, adding many useful features to enrich your content. Left-to-Right, with all languages and most plugins.

RELEASE NOTES:
- CKEditor Version 4.4.4 Full.
- Moonocolor skin.
- Linked to Opencart Image Manager.
- Resizable CKEditor window.
- Disables the auto-generation of <p> tags.
- Disables the auto-generation of <br /> tags.
- Uses CodeMirror plugin.

BROWSER COMPATIBILITY: 
CKEditor 4.4.4 Full has been tested in the following browsers, Firefox, IE8/9/10, Safari, Chrome, Opera. 
All passed OK! Other browsers were not tested.

-----------------------------------------------------------------------------------------
INSTALLATION:

FIRST STEP, you must Remove ALL default "ckeditor" files:
1 - Go to: ../admin/view/javascript/. and manually delete the OLD "ckeditor" folder completely.

SECOND STEP, Install the new files:
2 - Unzip the downloaded file in the folder of your choice.
3 - Go to: ../admin/view/javascript/. and manually upload the NEW "ckeditor" folder.
4 - In admin, check that CKeditor loads correctly (open Catalog > Categories for example).
5 - ... you might have to press "CTRL-F5" once or twice, to refresh your browser's cache.
-----------------------------------------------------------------------------------------
100% NEW FILES !
-----------------------------------------------------------------------------------------

WEBMASTERS:
You can further customise your editor by editing the "config.js" file, located here: ../admin/view/javascript/ckeditor/config.js

FOR MAC USERS:
This file has been compressed in a ZIP format under Windows. 
You can UNZIP it using �The unarchiver� (see link below)
Link: http://www.macupdate.com/info.php/id/22774/the-unarchiver

SUPPORT EMAIL: 
This module is freeware and provided as is, there is no support as such, but I'm happy to answer your questions. 

enjoy ^_^
